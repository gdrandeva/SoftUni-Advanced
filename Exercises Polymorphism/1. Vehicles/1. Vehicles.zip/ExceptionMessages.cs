﻿

namespace Vehicles
{
    public static class ExceptionMessages
    {
        public const string InsufficientFuelExceptionMessage =
            "{0} needs refueling";
    }
}
