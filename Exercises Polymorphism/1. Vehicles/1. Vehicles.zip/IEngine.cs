﻿

namespace Vehicles
{
   public interface IEngine
    {
        void Run();
    }
}
