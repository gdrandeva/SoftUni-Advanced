﻿

namespace Vehicles
{ 
    public interface IReader
    {
        string ReadLine();
    }
}
